﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cppobjectcalling
{
    class Program
    {
        static void Main(string[] args)
        {
            int noOfElemnt = 3;
            int[] array = new int[noOfElemnt];
            array[0] = 10;
            array[1] = 20;
            array[2] = 30;
            unsafe
            {
                fixed (int* pOfArray = &array[0])
                {
                    wrapperClass.cppWrapperClass cntrlcpp = new wrapperClass.cppWrapperClass(pOfArray, noOfElemnt);
                    int _sum = cntrlcpp.getSum();
                    Console.WriteLine("sum of array {0}", _sum);
                    Console.ReadKey();
                }
            }
        }
    }
}
