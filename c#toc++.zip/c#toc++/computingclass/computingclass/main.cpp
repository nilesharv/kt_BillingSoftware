#include "header.h"
#include<iostream>
void main()
{
	int noOfElement =3;
	int *myArray=new int[noOfElement];
	myArray[0]=15;
	myArray[1]=75;
	myArray[2]=10;
	ComputingClass cc(myArray,noOfElement);
	int _sum=cc.sumArray();
	std::cout<<_sum;
	std::cin;
}