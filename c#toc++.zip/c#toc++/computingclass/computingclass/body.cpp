#pragma once
#include "header.h"
#include <vector>
using namespace std;
ComputingClass::ComputingClass(int *pInt,int arrSize)
{
	for(int i=0;i<arrSize;i++)
	{
		vec.push_back(pInt[i]);
	}
}

int ComputingClass::sumArray()
{
	int _sum=0;

	for(int i=0;i<vec.size();i++)
		_sum+=vec[i];

	return _sum;
}