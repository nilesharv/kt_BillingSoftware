#pragma once
#include <vector>

using namespace std;

class ComputingClass
{
private:
	vector<int> vec;
public :

	ComputingClass(int *pInt,int arrSize);
	int sumArray();


};
