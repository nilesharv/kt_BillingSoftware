// This is the main DLL file.

#include "stdafx.h"

#include "wrapperClass.h"

#include "C:\Users\ktuser\Documents\Visual Studio 2010\Projects\computingclass\computingclass\header.h"
#include "C:\Users\ktuser\Documents\Visual Studio 2010\Projects\computingclass\computingclass\body.cpp"

 wrapperClass::cppWrapperClass::cppWrapperClass(int *pInt,int arrSize)
 {
	 pcc=new ComputingClass(pInt,arrSize);
 }

int wrapperClass::cppWrapperClass::getSum()
 {
	 _sum=pcc->sumArray();
	 return _sum;
 }
