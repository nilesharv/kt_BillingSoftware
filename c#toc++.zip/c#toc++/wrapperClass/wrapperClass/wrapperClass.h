// wrapperClass.h

#pragma once
#include "C:\Users\ktuser\Documents\Visual Studio 2010\Projects\computingclass\computingclass\header.h"
#include "C:\Users\ktuser\Documents\Visual Studio 2010\Projects\computingclass\computingclass\body.cpp"
using namespace System;

namespace wrapperClass {

	public ref class cppWrapperClass
	{
	public:
		cppWrapperClass(int *pInt,int arrSize);
		int _sum;
		int getSum();
	private:
		ComputingClass *pcc;

	};
}
