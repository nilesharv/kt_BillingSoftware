#include<stdio.h>
#include<stdlib.h>

extern "C"{

	__declspec(dllexport) int sum(int a[],int b[],int an,int bn)
	{


	}

}