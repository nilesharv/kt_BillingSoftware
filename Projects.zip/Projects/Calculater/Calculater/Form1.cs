﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace Calculater
{
    public partial class Form1 : Form
    {
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder Sum(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder minus(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder mul(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder div(StringBuilder a, StringBuilder b, int n1, int n2);


        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
        }
    }
}
