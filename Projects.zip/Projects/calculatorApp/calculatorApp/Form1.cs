﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace calculatorApp
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder Sum(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder minus(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder mul(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder div(StringBuilder a, StringBuilder b, int n1, int n2);
     

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder a = new StringBuilder(textBox2.Text);
            StringBuilder b = new StringBuilder(textBox3.Text);
            StringBuilder res = Sum(a, b, a.Length, b.Length);
            textBox1.Text = res.ToString();
            op.Text = "+";
        }

        private void button3_Click(object sender, EventArgs e)
        {

            StringBuilder a = new StringBuilder(textBox2.Text);
            StringBuilder b = new StringBuilder(textBox3.Text);
            //StringBuilder res = Sum(a, b, a.Length, b.Length);
           // textBox1.Text = res.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            StringBuilder a = new StringBuilder(textBox2.Text);
            StringBuilder b = new StringBuilder(textBox3.Text);
            StringBuilder res = minus(a, b, a.Length, b.Length);
            op.Text = "-";
            textBox1.Text = res.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            StringBuilder a = new StringBuilder(textBox2.Text);
            StringBuilder b = new StringBuilder(textBox3.Text);
            StringBuilder res = mul(a, b, a.Length, b.Length);
            textBox1.Text = res.ToString();
            op.Text = "*";
        }
    }
}
