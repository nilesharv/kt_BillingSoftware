﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Data;

namespace ConsoleApplication2
{
   public class Item
    {

        public string name { get; set; }

        public int rollno { get; set; }

    }


    class Program
    {
        static void Main(string[] args)
        {

            // Create and instance of XmlSerializer class. 
     XmlSerializer xmlSerializer = new XmlSerializer(typeof(DataSet));
     // Create a DataSet; adds a table, column, and ten rows.
     DataSet cameraDS = new DataSet("Camera");
     // Create DataTable.
     DataTable cameraDT = new DataTable("CameraDetails");
     // Specify columns of a DataTable
     cameraDT.Columns.Add("MakeModel"); //Column1
     cameraDT.Columns.Add("Price"); //Column2s
     // Add rows in DataTable
     cameraDT.Rows.Add("Canon EOS-1D","$5219");
     cameraDT.Rows.Add("Canon EOS-1D Mark IV","$5000");
     // Add DataTable in DataSet
     cameraDS.Tables.Add(cameraDT);
     // Create an instance of stream writer.
     TextWriter txtWriter = new StreamWriter(@"C:Serialization ExamplesDataSetSerialization.xml");
     // Serialize the instance of BasicSerialization
     xmlSerializer.Serialize(txtWriter, cameraDS);
     // Close the stream writer
     txtWriter.Close();

        }
    }
}
