#include<stdio.h>
#include<string.h>
#include<iostream>
#define charToDigit(a) a-'0'
extern "C"{

	__declspec(dllexport) extern char* Sum(char *a,char *b)
	{

	_strrev(a);
		_strrev(b);
	int n1=4;
	int n2=4;
	char *result= new char[100];
	int c=0;
	int k=0;
		for(int i=0;i<n1||n2;i++)
		{
			if(i<n1&&i<n2)
			{
				result[k]=(a[i]-'0'+b[i]-'0'+c)%10+'0';
				c=(a[i]-'0'+b[i]-'0'+c)/10;
				k++;
			}
			else
				if(i<n1)
				{
				result[k]=(a[i]-'0'+c)%10+'0';
				c=(a[i]-'0'+c)/10;
				k++;
				}
				else
					{
				result[k]=(b[i]-'0'+c)%10+'0';
				c=(b[i]-'0'+c)/10;
				k++;
			   }

		}

		if(c>0)
		{	result[k]=c+'0';
		k++;
		}

		result[k]='\0';

		_strrev(result);
		
		printf("%s",result);
		//return result;

	return result;
	}



}