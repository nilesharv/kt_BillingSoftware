﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace CollabApp_1
{
    class Program
    {
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\CollabApp_1\Debug\testbyme.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]

        public static extern int square(int x);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\CollabApp_1\Debug\testbyme.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr getString(char[] a,char[] b);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\CollabApp_1\Debug\testbyme.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int getSum(
            [MarshalAs(UnmanagedType.LPArray)]
            int[] m,int n);

[DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\CollabApp_1\Debug\calculater.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder Sum(StringBuilder a,StringBuilder b);
      
        static void Main(string[] args)
        {

            StringBuilder a = new StringBuilder("1234\0", 4);
            StringBuilder b = new StringBuilder("4321\0", 4);
            StringBuilder c = Sum(a, b);

         //  IntPtr data= getString(a.ToCharArray(),b.ToCharArray());
          // string str = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(data);

            Console.WriteLine(c.ToString());
            
            Console.ReadKey();
        }
    }
}