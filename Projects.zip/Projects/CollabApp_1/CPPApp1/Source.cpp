#include <stdio.h>

extern "C"{

	__declspec(dllexport) void function(){
		printf("Hello World");
	}
}