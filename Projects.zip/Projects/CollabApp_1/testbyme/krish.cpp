#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<string>
#include<vector>

extern "C"{

	__declspec(dllexport) int square(int x){
		
		printf("printing using c++ %d",x);
		return x*x;

		}
		__declspec(dllexport) char* getString(char a[],char b[])
		 {
			int i=strlen(a);
			printf("char length=%d",i);
			//printf("%s",a);
			//printf("%s",b);
			return strcat(a,b);
		 }

		_declspec(dllexport) int getSum(int v[],int n)
		 {
			int _sum=0;
			for(int i=0;i<n;i++)
				_sum+=v[i];
			v[3]=25;
			return _sum;
		 }
	
}