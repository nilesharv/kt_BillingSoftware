﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
//using System.Runtime.Serialization;
//using System.Runtime.Serialization.Formatters.Binary;



namespace ConsoleApplication1
 {                  /* main function and main screen controler*/
                                                        class Program
                                                        {
                                                                    static void Main(string[] args)
                                                                    {
                                                                        Inventory inventory=new Inventory(); //
                                                                        ArrayList goods = new ArrayList();
                                                                        XmlSerializer stock = new XmlSerializer(typeof(Object[]));
                                                                     //   TextReader txtReader = new StreamReader(@"C:stock.xml");
                                         
                                                                       // goods = (ArrayList)stock.Deserialize(txtReader) as ArrayList;
                                                                       // txtReader.Close();
                                                                        bool flag=true;
                                                                        while(flag)
                                                                        {
                                                                        Console.Clear();
                                                                            Console.WriteLine("1. Update Inventory \n");
                                                                            Console.WriteLine("2. Sell Inventory  \n");
                                                                            Console.WriteLine("3. Exit  \n");
                                                                            Console.WriteLine("Enter your option: ");
                                                                            int x = int.Parse(Console.ReadLine());

                                                                            switch (x)
                                                                            {
                                                                                case 1:
                                                                                    inventory.update(goods);
                                                                                    break;
                                                                                case 2:
                                                                                    inventory.sell(goods);
                                                                                    break;
                                                                                case 3:
                                                                                    flag = false;
                                                                                    break;

                                                                            }
                                                                        }
                                                                        try
                                                                        {
                                                                            TextWriter writer = new StreamWriter(@"C:stock.xml");
                                                                            stock.Serialize(writer,goods.ToArray());
                                                                            writer.Close();


                                                                        }
                                                                        catch (Exception ex)
                                                                        {

                                                                        }
                                                                     
                                                                    }
                                                        }
                                                                                            /*data structure for storing Item in inventory*/
                                                                                          
                                                                                               public class Accessories 
                                                                                                {
                                                                                                    public int type { get; set; }
                                                                                                    public string name { get; set; }
                                                                                                    public int price { get; set; }
                                                                                                    public int quantity { get; set; }
                                                                                                 public Accessories()
                                                                                                    {
                                                                                                        type = 0;
                                                                                                        name = "null";
                                                                                                        price = 0;
                                                                                                        quantity = 0;

                                                                                                    }
        
                                                                                                }

    /*This is class is used to control inventory having method to add,modify,remove item*/
                            class Update
                            {

                                public void add(ArrayList goods)
                                {
                                    Accessories newA = new Accessories();
                                    Console.WriteLine("Enter type code(integer) :");
                                    newA.type = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter product name(character) :");
                                    newA.name = Console.ReadLine();
                                    Console.WriteLine("Enter price(integer) :");
                                    newA.price = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter quantity(integer) :");
                                    newA.quantity= int.Parse(Console.ReadLine());
                                    goods.Add(newA);
                                }

                                public void modify(ArrayList goods)
                                {
                                    view(goods);
                                    Console.WriteLine("enter serial no to edit Accesories");
                                    int num = int.Parse(Console.ReadLine());
                                    Accessories a = (Accessories)goods[num];
                                    goods.RemoveAt(num);
                                    Console.WriteLine("add quantity of "+a.name);
                                    a.quantity += int.Parse(Console.ReadLine());
                                    goods.Insert(num, a);
                                }

                                public void remove(ArrayList goods)
                                {

                                }

                                public void view(ArrayList goods)
                                {
                                    int i = 0;
                                    Console.WriteLine("Sl. no"+ "\t" +"product code" + "\t" + "product name" + "\t" + "price" + "\t" + "quntity");
                                    foreach (Accessories a in goods)
                                    {
                                        Console.WriteLine(i+"\t\t"+a.type + "\t\t" + a.name + "\t\t" + a.price + "\t\t" + a.quantity);
                                        i++;
                                    }
                                }

                            }

                                                            /*this is data structure is used to store customer Item as bucket*/

                                                                                   public class Item
                                                                                    {
                                                                                       public  Accessories item;
                                                                                       public int quantity { get; set; }
                                                                                       public double total = 0;
                                                                                       public Item()
                                                                                       {
                                                                                           item = null;
                                                                                           total = 0;
                                                                                           quantity = 0;
                                                                                       }
                                                                                        public Item(int q,Accessories a)
                                                                                        {
                                                                                            a.quantity -= q;
                                                                                            item = a;
                                                                                            quantity = q;
                                                                                            total = q * item.price;
                                                                                        }

                                                                                        public void view(int i)
                                                                                        {
                                                                                       
                                                                                          Console.WriteLine(i + "\t" + item.name + "\t" + item.price + "\t"+quantity+"\t" +total);
                                                                                        }
                                                                                        public void editQuantitiy(int num)
                                                                                        {
                                                                                            quantity += num;
                                                                                            item.quantity += num;
                                                                                            total = quantity * item.price;
                                                                                        }

                                                                                        public double getCost()
                                                                                        {
                                                                                            return total;
                                                                                        }
                                                                                    }

   /* this is class is used to ccontrol all work of billing system provide two methods.. 1. for customer 2. for shopkeeper*/
                        class Inventory
                        {

                            public void update(ArrayList goods)
                            {
                                Update updateInv = new Update();
                                bool flag = true;
                                while (flag)
                                {
                                    Console.Clear();
                                    Console.WriteLine("1. Add Inventory \n");
                                    Console.WriteLine("2. modify Inventory \n");
                                    Console.WriteLine("3. check Inventory  \n");
                                    Console.WriteLine("4. Exit  \n");
                                    Console.WriteLine("Enter your option: ");
                                    int x = int.Parse(Console.ReadLine());

                                    switch (x)
                                    {
                                        case 1:
                                            updateInv.add(goods);
                                            break;
                                        case 2:
                                            updateInv.modify(goods);
                                            break;
                                        case 3:
                                            updateInv.view(goods);
                                            Console.ReadLine();
                                            break;
                                        case 4:
                                            flag = false;
                                            break;

                                    }
                                }
                            }

        
                            public void sell(ArrayList goods)
                            {
                                string name;
                                bool flag = true;
                                double total=0;
                                Console.WriteLine("Enter coustomer name ");
                                name = Console.ReadLine();
                                Update updateInv = new Update();
                                XmlSerializer customerData = new XmlSerializer(typeof(Item));
                                TextWriter bill = new StreamWriter(name + ".xml");
                                ArrayList itemList = new ArrayList();
                                while (flag)
                                {
                                    Console.Clear();
                                    Console.WriteLine("1. Add Item \n");
                                    Console.WriteLine("2. Remove Item\n");
                                    Console.WriteLine("3. view Item \n");
                                    Console.WriteLine("4. Done  \n");
                                    Console.WriteLine("Enter your option: ");
                                    int x = int.Parse(Console.ReadLine());

                                    switch (x)
                                    {
                                        case 1:
                                            updateInv.view(goods);
                                            Console.WriteLine("enter serial no");
                                            int num = int.Parse(Console.ReadLine());
                                            Accessories a = (Accessories)goods[num];
                                            Console.WriteLine("enter quantity");
                                            int q = int.Parse(Console.ReadLine());
                                            itemList.Add(new Item(q, a));
                                            break;
                                        case 2:
                                            updateInv.modify(goods);
                                            break;
                                        case 3:
                                            total=0;
                                            int j = 0;
                                            foreach (Item itemA in itemList)
                                            {
                                                itemA.view(j);
                                                total += itemA.getCost();
                                                j++;
                                            }
                                            Console.WriteLine("Total :" + total);
                                            Console.ReadLine();
                                            break;
                                        case 4:
                                            total=0;
                                            int c = 0;
                                            Console.WriteLine("Customer: " + name);
                                            foreach (Item itemB in itemList)
                                            {
                                                itemB.view(c);
                                                customerData.Serialize(bill, itemB);
                                                total += itemB.getCost();
                                                c++;
                                            }
                                            Console.WriteLine("Total :" + total);
                                            Console.WriteLine("Thank you for shopping");
                                            Console.ReadLine();

                                            flag = false;
                                                break;

                                    }
                                            
                                }

                                bill.Close();

        }
    }



    

}
