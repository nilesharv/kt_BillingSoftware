﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Xml;

namespace ConsoleApplication3
{
class program

{

static void Main(string[] args)

{
   /*
XmlSerializer s=new XmlSerializer(typeof(Configuration), new Type[]{typeof(A)});

TextWriter save=new StreamWriter(@"save.xml");

Configuration c=new Configuration();

c.Pname="sony earphone";

c.Ptype="mobile earplug";

c.quantitiy=10;

c.price=1399.00f;

c.p_details=new ProductDetails("sony earphone","12345","01-02-2016","20-12-2050");

c.list = new List<A>();

B b = new B();
b.cname = "B";
b.pname = "BA";

C cc = new C();
cc.cname = "C";
cc.pname = "CA";

D d = new D();
d.cname = "D";
d.pname = "DA";

c.list.Add(b);
c.list.Add(cc);
c.list.Add(d);
s.Serialize(save,c);

//Console.WriteLine(save.ToString());
save.Close();
    
    
    //desearlize
    */

//Deserialize
XmlSerializer xr = new XmlSerializer(typeof(Configuration));
XmlDocument xd = new XmlDocument();
string w = File.ReadAllText(@"save.xml");
Console.WriteLine(w);
xd.LoadXml(w);
XmlNodeReader nr = new XmlNodeReader(xd.DocumentElement);
Configuration obj1 =(Configuration) xr.Deserialize(nr);

    Console.WriteLine(obj1.Pname+" "+obj1.price);
char a = Console.ReadKey().KeyChar;

  
}



}


    [Serializable]
    [XmlInclude(typeof(A))]
    [XmlInclude(typeof(B))]
    [XmlInclude(typeof(C))]
    [XmlInclude(typeof(D))]
    [XmlInclude(typeof(Object))]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace ="http://BaseNameSpace", IsNullable = true)]

    public class Configuration

{

public string Pname {get;set;}

public string Ptype {get;set;}

public int quantitiy {get;set;}

public float price {get;set;}

public ProductDetails p_details;

public List<A> list {get;set;}

public Configuration()

{


Pname=null;

Ptype=null;

quantitiy=0;

price=0.0f;

p_details=null;

}

}


    [Serializable]
public class ProductDetails

{

public string name {get;set;}

public string batch_no {get;set;}

public string mfg_date {get;set;}

public string exp_date {get;set;}



public ProductDetails()

{

name=null;

batch_no=null;

mfg_date=null;

exp_date=null;

}

public ProductDetails(string n,string b,string m,string e)

{



name=n;

batch_no=b;

mfg_date=m;

exp_date=e;



}



}


    [Serializable]
public class A 

{

public string pname;

}

    [Serializable]
    [XmlInclude(typeof(A))]
public class B : A 

{

    public string cname;

}

    [Serializable]
public class C : A 

{

    public string cname;

}


    [Serializable]
public class D : A 

{
    public string cname;
}





}
