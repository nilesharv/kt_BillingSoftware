#pragma once
class test
{
public:
	test(void);
	virtual ~test(void);
	int number;
	int getNumber();
	
};

