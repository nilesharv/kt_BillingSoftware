#include "test.h"


test::test(void)
{
	number=0;
}


test::~test(void)
{
}

int test::getNumber()
{
	return number;
}