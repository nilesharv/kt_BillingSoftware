#include<stdio.h>

extern "C"{
	__declspec(dllexport) int sumOfTwo(int x,int y){
		return x+y;

	}

}