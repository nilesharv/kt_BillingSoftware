﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
namespace ConsoleApplication5
{
    class Program
    {
         [DllImport(@"C:\Users\ktuser\Documents\visual studio 2010\Projects\ConsoleApplication5\Debug\testApp.dll",CallingConvention=CallingConvention.Cdecl)]
        public static extern int sumOfTwo(int x,int y);
        static void Main(string[] args)
        {
            Console.WriteLine(sumOfTwo(3, 5));
            Console.ReadKey();

        }
    }
}
