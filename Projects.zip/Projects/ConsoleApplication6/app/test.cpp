#include<stdio.h>
#include<string.h>

#define ctod(a) (a-'0')
#define dtoc(b) (b+'0')
extern "C"{



	__declspec(dllexport) extern char* Sum(char *a,char *b,int n1,int n2)
	{
		char *result= new char[n1+n2];
		result[0]='\0';
		//strcat(result,a);
		a[n1]='\0';
		b[n2]='\0';
strrev(a);
strrev(b);
strcat(result,a);
strcat(result,b);
	int c=0;
	int k=0;
	for(int i=0;i<n1||i<n2;i++)
	{

		if(i<n1&&i<n2)
		{
			int t=ctod(a[i])+ctod(b[i])+c;
			c=t/10;
			t=t%10;
			result[k]=dtoc(t);
			k++;
		}
		else
			if(i<n1)
			{
				int t=ctod(a[i])+c;
				c=t/10;
				t=t%10;
				result[k]=dtoc(t);
				k++;
			}
			else
				if(i<n2)
				{
					int t=ctod(b[i])+c;
					c=t/10;
					t=t%10;
					result[k]=dtoc(t);
					k++;
				}
	}

	if(c>0)
	{
		result[k]=dtoc(c);
		k++;
	}

	result[k]='\0';
	strrev(result);
	return result;

	}


	

	__declspec(dllexport) extern char* minus(char *a,char *b,int n1,int n2)
	{
		
		if(n2>n1)
		{
			char *c=a;
			a=b;
			b=a;
			int n=n2;
			n2=n1;
			n1=n;
		}

		
		char *result= new char[n1+n2];
		result[0]='\0';
		//strcat(result,a);
		a[n1]='\0';
		b[n2]='\0';
strrev(a);
strrev(b);
strcat(result,a);
strcat(result,b);
	int c=0;
	int k=0;
	int i;
	for(i=0;i<n1&&i<n2;i++)
	{
			int t=ctod(a[i])-ctod(b[i]);
			if(t<0)
				{t+=10;
			a[i+1]=dtoc(ctod(a[i+1])-1);
			}
			result[i]=dtoc(t);
	}

	while(i<n1)
	{	
		int t=ctod(a[i]);
			if(t<0)
				{t+=10;
			a[i+1]=dtoc(ctod(a[i+1])-1);
			   }
			result[i]=dtoc(t);
	}

	
	int j=i-1;
	while(j>0&&result[j]=='0')
	{j--;
	}
	result[j+1]='\0';
	strrev(result);
	return result;

	}

__declspec(dllexport) extern char* mul(char *a,char *b,int n1,int n2)
	{
		
		if(n2>n1)
		{
			char *c=a;
			a=b;
			b=a;
			int n=n2;
			n2=n1;
			n1=n;
		}

		
		char *result= new char[n1+n2];
		result[0]='\0';
		//strcat(result,a);
		a[n1]='\0';
		b[n2]='\0';
strrev(a);
strrev(b);
//strcat(result,b);
	int c=0;
	int k=0;
	int j=0;
	for(int i=0;i<n1+n2;i++)
		result[i]=0;
for(int i=0;i<n1;i++)
{
	for(j=0;j<n2;j++)
	{
		result[j+k]+=ctod(a[i])*ctod(b[j]);
	//	printf("%d",result[i]);
	}
	k++;
}
c=0;
//for(int i=0;i<n1+k;i++)
	//printf("%d ",result[i]);
int i=0;
for(i=0;i<n2+k;i++)
{
	c=result[i]+c;
	result[i]=dtoc((c%10));
	c=c/10;
}
while(c>0)
{
	result[i]=dtoc(c%10);
	c=c/10;
	i++;
}
while(i>0&&result[i]=='0')
{
i--;
}
result[i+1]='0';
strrev(result);
return result;

	}

int lessThan(char *a,char *b,int n1,int n2)
{
	printf("less than\n");
	if(n2>n1)
		return 1;
	else
		if(n1>n2)
			return 0;

	for(int i=0;i<n1;i++)
	{
		if(a[i]<b[i])
			return 1;
		else
			if(b[i]<a[i])
				return 0;
	}

return -1;
}

__declspec(dllexport) extern char* div(char *a,char *b,int n1,int n2)
	{
		char *result;
		while(lessThan(a,b,n1,n2)==0)
		{
			result=minus(a,b,n1,n2);
			a=result;
			n1=strlen(result);
			printf("in\n");
		}

		return result;
    }

}