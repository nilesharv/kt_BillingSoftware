﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
namespace ConsoleApplication6
{
    class Program
    {
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder Sum(StringBuilder a, StringBuilder b,int n1,int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder minus(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder mul(StringBuilder a, StringBuilder b, int n1, int n2);
        [DllImport(@"C:\Users\ktuser\Documents\Visual Studio 2010\Projects\ConsoleApplication6\Debug\app.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern StringBuilder div(StringBuilder a, StringBuilder b, int n1, int n2);
      
        static void Main(string[] args)
        {
            StringBuilder a = new StringBuilder("1234", 4);
            StringBuilder b = new StringBuilder("123", 3);
            StringBuilder c = Sum(a, b, a.Length, b.Length);
                StringBuilder d = minus(a,b,a.Length,b.Length);
                StringBuilder e = mul(a, b, a.Length, b.Length);
            Console.WriteLine(e.ToString());
            Console.ReadKey();
        }
    }
}
