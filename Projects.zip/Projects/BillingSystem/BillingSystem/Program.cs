﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BillingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            //Work work = new Work();
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1. Update Inventory \n");
                Console.WriteLine("2. Sell Inventory  \n");
                Console.WriteLine("3. Exit  \n");
                Console.WriteLine("Enter your option: ");
                int x = int.Parse(Console.ReadLine());
              /*  switch (x)
                {
                    case 1:
                        work.updateInventory();
                        break;
                    case 2:
                        work.sellInventory();
                        break;
                    case 3:
                        flag = false;
                        break;
                }*/
               
            }
           // string s = Console.ReadLine();

        }
    }
   /* class Work
    {
        public void updateInventory()
        {
            Console.WriteLine("hi i am update function");

        }

        public void sellInventory()
        {
            Console.WriteLine("hi i am sell function");
        }

    }*/
}



